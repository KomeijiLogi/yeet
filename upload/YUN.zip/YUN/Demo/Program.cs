﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YUN;
using Newtonsoft.Json;
using RSATest;

namespace Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            //TestAccesToken();
            //TestPubSend();
            //TestGetYunUser();
            //TestChangeTodoMsgStatus();
            TestGetDept();
            //TestGetPer();
            //TestGZH();
            //TestEncrypt();
            Console.ReadLine();

        }
        async static void TestGetDept() {

            //string nonce = Guid.NewGuid().ToString();       
            string nonce = DateTime.Now.CurrentTimeMillis().ToString();
            nonce = "1493949396901";
            string eid = "102";
            var data = new
            {
                eid = eid
            };
            byte[] bytes = YUNAPI.fileReader("D:/working/102.key");

            byte[] key=  YUNAPI.restorePrivateKey(Convert.ToString(bytes));

            string dataJSON = JsonConvert.SerializeObject(data);
            //string dataToken = Convert.ToBase64String(Encoding.UTF8.GetBytes(YUNAPI.encryptLarger(dataJSON, key)));

            string dataToken = "JNiyjrhYSFHGqh8h++rZ3pdGGWd6gAWBJxZitlazxJ37HngujAArZim/WDVKKQdq182VmhaD4M31isnJ5lx2GAZSW9rSrnVVkRiqzhslW4d2t5NJR9N7NmDP1ve2WpHuQLeGlpFx90D87bzAYsj300GnM/5qmEzAjEthc62H5q9of9Ja+GEohVhT8qoO9txP";
            var message = new
            {
                nonce = nonce,
                eid = eid,
                data = dataToken

            };


            string messageJSON = JsonConvert.SerializeObject(message);
            Console.WriteLine(messageJSON);
            try {
                DeptOutputDTO result = await YUNAPI.GetDept(messageJSON);

                
            }
            catch (Exception e) {

            }
            

        }
         static void TestEncrypt() {
           
            
            //byte[] bytes = YUNAPI.FileReader("D:/working/102.key");

            //string key = YUNAPI.EncryptToRSA(bytes.ToString());

            //string context = "aaaa";
            //string result = Convert.ToBase64String(Encoding.UTF8.GetBytes(RSAHelper.EncryptString(context, key)));
            
            //Console.WriteLine(result);
           

        }

        async static void TestGetPer()
        {

            string nonce = Guid.NewGuid().ToString();
            string eid = "102";
            int begin = 0;
            int count = 1000;
            //string begin = "0";
            //string count = "1000";
            string time = "2015-05-26 01:40:38";
            var data = new
            {
                eid = eid,
                time=time,
                begin=begin,
                count=count
            };
            byte[] bytes = YUNAPI.fileReader("D:/working/102.key");

            string key = YUNAPI.EncryptToRSA(bytes.ToString());
            string dataJSON = JsonConvert.SerializeObject(data);
            string dataToken = Convert.ToBase64String(Encoding.UTF8.GetBytes(RSAHelper.EncryptString(dataJSON, key)));

            
            var message = new
            {
                nonce = nonce,
                eid = eid,
                data = dataToken

            };

            string messageJSON = JsonConvert.SerializeObject(message);
            try
            {
                PerOutputDTO result = await YUNAPI.GetPer(messageJSON);
                
            }
            catch (Exception e)
            {

            }


        }


        static async void TestAccesToken()
        {
            string appID = "10209";//轻应用注册到云之家时生成
            string appSecret = "100000";//轻应用注册到云之家时生成
            

            AccessToken accessToken = await YUNAPI.GetAccessTokenAsync(appID, appSecret);
            Console.Write(accessToken.access_token);
        }
        //推送待办消息
        static void TestPubSend()
        {
            string pubKey = "fca5dd5c9e2bade7ee11f019334f8fc5";
            string no = "102";
            string pub = "XT-09a0511f-d9c1-46d5-bc5a-127dd3ec21ab";
            string time = DateTime.Now.CurrentTimeMillis().ToString();
            string nonce =  Guid.NewGuid().ToString();
            string pubtoken = YUNAPI.CreatePubToken(no, pub, pubKey, nonce, time);
            var message = new
            {
                from = new
                {
                    no = no,
                    pub = pub,
                    time = time,
                    nonce = nonce,
                    pubtoken = pubtoken
                },
                to = new object[]{
                        new {
                            no= no,
                            user=new string[] { "00000088","00078251" },
                            code=YUNAPI.PUBCODE_ACCOUNT
                            }
                    },
                type = YUNAPI.PUBTYPE_TEXTANDHREF,
                msg = new
                {
                    url = "http://www.baidu.com?id=**&param=...",
                    appid = "10207",
                    todo =YUNAPI.TODO_YES,
                    text = "外勤审批",
                    todoPriStatus=YUNAPI.TODOSTAUS_UNDO,//只能是undo  待办
                    extendFields =new { pushTipTitle="金蝶云之家给你推了一条审批流程！" }
                 }
            };
            string json = JsonConvert.SerializeObject(message);
            var r=  YUNAPI.PubSend(json);
            Console.Write(r.message);
        }


        public static void TestGZH() {


            string pubKey = "fca5dd5c9e2bade7ee11f019334f8fc5";
            string no = "102";
            string pub = "XT-09a0511f-d9c1-46d5-bc5a-127dd3ec21ab";
            string time = DateTime.Now.CurrentTimeMillis().ToString();
            string nonce = Guid.NewGuid().ToString();
            string pubtoken = YUNAPI.CreatePubToken(no, pub, pubKey, nonce, time);
            var message = new
            {
                from = new
                {
                    no = no,
                    pub = pub,
                    time = time,
                    nonce = nonce,
                    pubtoken = pubtoken
                },
                to = new object[]{
                        new {
                            no= no,
                            user=new string[] { "00078251" },
                            code=YUNAPI.PUBCODE_ACCOUNT
                            }
                    },
                type = YUNAPI.PUBTYPE_TEXTANDHREF,
                msg = new
                {
                    url = "http://www.baidu.com?id=**&param=...",
                   
                    appid = "10209",

                    todo = YUNAPI.TODO_NO,
                    text = "审批流程",
                    todoPriStatus = YUNAPI.TODOSTAUS_UNDO,//只能是undo  待办
                    extendFields = new { pushTipTitle = "金蝶云之家给你推了一条审批流程！" }
                }
            };
            string json = JsonConvert.SerializeObject(message);
            var r =  YUNAPI.PubSend(json);
        }


        async static void TestGetYunUser()
        {
            //在云之家上访问轻应用时（公共号菜单、公共号带链接消息、应用中心中轻应用，带appid的应用），
            //云之家会传递ticket参数给轻应用。 轻应用可以从请求中获取。
            string ticket = "9cdeef8ea06fc30851f2ee4084e7605c";// 
            
            string appID = "10209";//轻应用注册到云之家时生成
            string appSecret = "100000";//轻应用注册到云之家时生成
            YunUser user=await YUNAPI.GetYunUser(ticket, appID, appSecret);
            Console.Write(JsonConvert.SerializeObject(user));
               

        }


        


        //已办
        async static void TestChangeTodoMsgStatus()
        {
            string pubKey = "fca5dd5c9e2bade7ee11f019334f8fc5";
            string no = "102";
            string pub = "XT-09a0511f-d9c1-46d5-bc5a-127dd3ec21ab";
            string time = DateTime.Now.CurrentTimeMillis().ToString();
            string nonce = Guid.NewGuid().ToString();
            string pubtoken = YUNAPI.CreatePubToken(no, pub, pubKey, nonce, time);
            string[] todoMsgIds = new string[] { "b837d6f4-a1ee-48db-8f3f-9d97b51d0e64" };
            string[] account = new string[] { "00000088" };

            var message = new
            {
                no = no,
                pub = pub,
                time = time,
                nonce = nonce,
                pubtoken = pubtoken,
                todoMsgIds = "69dd3885-8e97-46cd-891d-ad42d5cb67f1,a7df94ef - a961 - 4eb6 - a174 - ce48b989f37b",// "a7df94ef-a961-4eb6-a174-ce48b989f37b",
                todoStatus=YUNAPI.TODOSTAUS_DONE,
                account= "00000088,00000081"
                
                //pubkey = "",
                //openId=  "" 

            };

            var result=await YUNAPI.ChangeTodoMsgStatus(JsonConvert.SerializeObject(message));
            Console.Write(result.success);
            Console.Write(result.resultCode);
            Console.Write(result.errorMsg);

        }

        
        
    }
}
