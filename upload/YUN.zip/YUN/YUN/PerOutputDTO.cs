﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YUN
{
    public class PerOutputDTO
    {
        public string openId;   //人员的openID

        public string name;     //姓名

        public string photoUrl; //头像URL

        public string phone;    //手机号码

        public string isHidePhone; //是否在通讯录中隐藏手机号码,0: 不隐藏; 1: 隐藏,默认为0

        public string email;     //邮箱

        public string department;//组织长名称

        public string jobTitle;  //职位

        public int gender;       //性别,0: 不确定; 1: 男; 2: 女

        public int status;       //状态 0: 注销，1: 正常，2: 禁用

        public int weight;      //权重（排序）    

        public int orgUserType; //1: 负责人， 0： 不是负责人
    }
}
