﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Net.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;

using System.Security.Cryptography;
using System.Collections.Generic;
using System.Dynamic;
using System.Numerics;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Engines;

namespace YUN
{
    
    public class YUNAPI
    {
        #region 常量定义
        /// <summary>
        /// 待办消息状态，已处理=done
        /// </summary>
        public static string TODOSTAUS_DONE = "done";
        /// <summary>
        /// 待办消息状态,待处理=undo
        /// </summary>
        public static string TODOSTAUS_UNDO = "undo";
        /// <summary>
        /// 是否推送待办消息，推送=1
        /// </summary>
        public static string TODO_YES = "1";
        /// <summary>
        /// 是否推送待办消息，不推送=0
        /// </summary>
        public static string TODO_NO = "0";
        /// <summary>
        /// 公共号所有订阅用户模式
        /// </summary>
        public static string PUBCODE_ALL = "all";
        /// <summary>
        /// 公共号账号模式
        /// </summary>
        public static string PUBCODE_ACCOUNT = "2";

        /// <summary>
        /// 公共号消息内容类型，纯文本信息=2
        /// </summary>
        public static string PUBTYPE_TEXT = "2";
        /// <summary>
        /// 公共号信息类型，文本链接信息=5
        /// </summary>
        public static string PUBTYPE_TEXTANDHREF = "5";
        /// <summary>
        /// 公共号信息类型，图文混排信息=6
        /// </summary>
        public static string PUBTYPE_TEXTANDPIC = "6";


        /// <summary>
        /// 排版展现模型 1:单条文本编排模板
        /// </summary>
        public static string PUBMODE_SINGLETEXT = "1";
        /// <summary>
        /// 排版展现模型 2:单条图文混排模板
        /// </summary>
        public static string PUBMODE_SINGLETEXTANDPIC = "2";
        /// <summary>
        /// 排版展现模型  3:多条图文混排模板 
        /// </summary>
        public static string PUBMODE_MULTITEXTANDPIC = "3";
        /// <summary>
        /// 排版展现模型 4:应用消息模板
        /// </summary>
        public static string PUBMODE_APPMSGTEMPLATE = "4";
        #endregion

        #region 公共号相关
        /// <summary>
        /// 公共号推送消息
        /// </summary>
        /// <param name="jsonContent" ></param>
        /// <returns>消息ID</returns>
        /// <see cref="http://erpcloud.kingdee.com/developer/?p=51"/>
        public static PubSendOutputDTO PubSend(string jsonContent)
        {
            //HTTP请求地址

            string url = string.Format("{0}/pubacc/pubsend", YUNXT);
            //url = "http://www.baidu.com?id=**&param=...";
            dynamic result = new PubSendOutputDTO();
            result.success = false;
            result.message = "fail";
            try {
                string resp = PostData(url, jsonContent);
                JObject obj = (JObject)JsonConvert.DeserializeObject(resp);
                var members = obj["members"];
                result.success = true;
                result.message = (string)members["msgId"];
            }
            catch(Exception ex)
            {
                //return new { success = false, msgId = "fail" };
            }
            return result;

        }

        /// <summary>
        /// 生成公共号pubtoken
        /// </summary>
        /// <param name="no">发送方企业的企业注册号(eID)</param>
        /// <param name="pub">发送使用的公共号编码</param>
        /// <param name="pubkey">公共号密钥</param>
        /// <returns></returns>
        public static string CreatePubToken(string no, string pub, string pubkey,string nonce, string time)
        {
            ArrayList list = new ArrayList() { no ,pub, pubkey, nonce, time};
            ASCIIStringCompare com = new ASCIIStringCompare();
            list.Sort(com);
            string strTemp = string.Join("", list.ToArray(typeof(string)) as string[]);
            return EncryptToSHA1(strTemp);
        }

     

        /// <summary>
        /// 修改待办消息状态
        /// </summary>
        /// <param name="jsonContent"></param>
        /// <returns></returns>
        async public static Task<ChangeTodoMsgStatusOutputDTO> ChangeTodoMsgStatus(string jsonContent)
        {
            //HTTP请求地址
            string url = string.Format("{0}/pubacc/changeTodoMsgStatus", YUNXT);
            var result = new ChangeTodoMsgStatusOutputDTO();
            result.success = false;
            
            try
            {
                string resp = await PostAsync(url, jsonContent);
                JObject obj = (JObject)JsonConvert.DeserializeObject(resp);
                var members = obj["members"];
                result.success = (bool)members["success"];
                result.errorMsg =(string)members["errorMsg"];
                result.resultCode = (string)members["resultCode"];
            }
            catch (Exception ex)
            {
               
            }
            return result;

        }
        #endregion

        #region 身份验证相关
        /// <summary>
        /// 可以使用AppID和AppSecret调用本接口来获取access_token。AppID和AppSecret在MCLOUD注册轻应用时获得。
        /// </summary>
        /// <param name="appID"></param>
        /// <param name="appSecret"></param>
        /// <returns></returns>
        async public static Task<AccessToken> GetAccessTokenAsync(string appID, string appSecret)
        {
            string url = string.Format("{0}/openauth2/api/token?grant_type=client_credential&appid={1}&secret={2}", YUNXT, appID, appSecret);
            string resp = await GetAsync(url);
            AccessToken accessToken = (AccessToken)JsonConvert.DeserializeObject(resp, typeof(AccessToken));
            return accessToken;

        }

        /// <summary>
        /// 获取云之家当前登录用户上下文
        /// </summary>
        /// <param name="ticket">ticket</param>
        /// <param name="accessToken">access_token</param>
        /// <returns></returns>
        async public static Task<YunUser> GetYunUser(string ticket,AccessToken accessToken)
        {
            string url = string.Format("{0}/openauth2/api/getcontext?ticket={1}&access_token={2}",YUNXT, ticket,accessToken.access_token);
            string resp = await GetAsync(url);
            YunUser user= (YunUser)JsonConvert.DeserializeObject(resp, typeof(YunUser));
            return user;
        }

        /// <summary>
        /// 取云之家当前登录用户上下文
        /// </summary>
        /// <param name="ticket"></param>
        /// <param name="appID"></param>
        /// <param name="appSecret"></param>
        /// <returns></returns>
        async public static Task<YunUser> GetYunUser(string ticket, string appID, string appSecret)
        {
            AccessToken accessToken=await GetAccessTokenAsync(appID, appSecret);
            return await GetYunUser(ticket, accessToken);
        }
        #endregion

        #region 私有方法、属性
        /// <summary>
        /// 消息域名
        /// </summary>
        private static string YUNXT
        {
            get
            {
                return GetValueFromConfig("yunxt");
            }
        }

        /// <summary>
        /// 从配置文件获取Value
        /// </summary>
        /// <param name="key">配置文件中key字符串</param>
        /// <returns></returns>
        private static string GetValueFromConfig(string key)
        {
            try
            {
                Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                //Console.WriteLine(config);
                //获取AppSettings的节点 
                AppSettingsSection appsection = (AppSettingsSection)config.GetSection("appSettings");
                return appsection.Settings[key].Value;
            }
            catch
            {
                return "";
            }
        }

        /// <summary>
        /// 获取由SHA1加密的字符串
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        private static string EncryptToSHA1(string str)
        {
            SHA1CryptoServiceProvider sha1 = new SHA1CryptoServiceProvider();
            byte[] str1 = Encoding.UTF8.GetBytes(str);
            byte[] str2 = sha1.ComputeHash(str1);
            sha1.Clear();
            (sha1 as IDisposable).Dispose();
            return BitConverter.ToString(str2).ToLower().Replace("-", "");
        }

       
     


        /// <summary>
        /// post数据
        /// </summary>
        /// <param name="url"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        async private static Task<string> PostAsync(string url, List<KeyValuePair<string, string>> data)
        {
            using (var client = new HttpClient())
            {
                
                var content = new FormUrlEncodedContent(data);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                HttpClient httpClient = new HttpClient();
                var response =  await client.PostAsync(url, content);
                
                var responseString = await response.Content.ReadAsStringAsync();
                return responseString;
            }
        }
        /// <summary>
        /// post数据
        /// </summary>
        /// <param name="url"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        async private static Task<string> PostAsync(string url, string data)
        {
            using (var client = new HttpClient())
            {
                
                var content = new StringContent(data);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                var response = await client.PostAsync(url, content);

                var responseString = await response.Content.ReadAsStringAsync();
                
                return responseString;
            }
        }

         private static String PostData(string url, string data)
        {
            using (var client = new HttpClient())
            {

                var content = new StringContent(data);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                var response = client.PostAsync(url, content);
                
               
                var responseString = response.Result.Content.ReadAsStringAsync().ToString();

                return responseString;
                
            }
        }



        async private static Task<string> PostDataAsync(string url, string data)
        {
            using (var client = new HttpClient())
            {
                
                //var content = new StringContent(JsonConvert.SerializeObject(data));
                
                var content = new StringContent(data);
                Console.WriteLine(content);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");


                content.Headers.ContentEncoding.Add("utf-8");

                //content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                var response = await client.PostAsync(url, content);

                //Console.WriteLine(response.ToString());
                var responseString = await response.Content.ReadAsStringAsync();
                
                return responseString;


            }
        }

        /// <summary>
        /// get数据
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        async private static Task<string> GetAsync(string url)
        {
            using (var client = new HttpClient())
            {
                var response = await client.GetAsync(url);
                var responseString = await response.Content.ReadAsStringAsync();
                return responseString;
            }
        }
        #endregion

        #region 获取部门相关
        /// <summary>
        /// 获取相关部门
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        async public static Task<DeptOutputDTO> GetDept(string message)
        {
            

            string url = string.Format("{0}/openaccess/input/dept/getall", YUNXT);
            List<KeyValuePair<string, string>> msg = new List<KeyValuePair<string, string>>();
            KeyValuePair<string, string> kvp_nonce= new KeyValuePair<string, string>("nonce", Guid.NewGuid().ToString());
            KeyValuePair<string, string> kvp_eid = new KeyValuePair<string, string>("eid", "102");
            var data = new
            {

                eid = "102",
               
            };
            byte[] bytes = fileReader("D:/working/102.key");

            byte[] key = YUNAPI.restorePrivateKey(Convert.ToString(bytes));

            string dataJSON = JsonConvert.SerializeObject(data);
            KeyValuePair<string, string> kvp_data = new KeyValuePair<string, string>("data", dataJSON);

            msg.Add(kvp_nonce);
            msg.Add(kvp_eid);
            msg.Add(kvp_data);

            //message = JsonConvert.SerializeObject(msg);

            var resultTmp = await PostDataAsync(url,msg.ToString());
            var result = new DeptOutputDTO();
            JObject obj = (JObject)JsonConvert.DeserializeObject(resultTmp);
            Console.WriteLine(obj.ToString());

            //var members = obj["members"];

            //result.id = (string)members["id"];
            //result.name = (string)members["name"];
            //result.parentId = (string)members["parentId"];
            //result.department = (string)members["department"];

            return result;

        }

        #endregion

        #region 获取组织人员相关
        /// <summary>
        /// 获取组织人员相关
        /// </summary>
        /// <param name="eid"></param>
        /// <param name="begin"></param>
        /// <param name="count"></param>
        /// <returns></returns>
        async public static Task<PerOutputDTO> GetPer(string message)
        {

            string url = string.Format("{0}/openaccess/input/person/getAtTime", YUNXT);

            //List<KeyValuePair<string, string>> msg = new List<KeyValuePair<string, string>>();
            //KeyValuePair<string, string> kvp_nonce= new KeyValuePair<string, string>("nonce", Guid.NewGuid().ToString());
            //KeyValuePair<string, string> kvp_eid = new KeyValuePair<string, string>("eid", "102");


            //var data = new {

            //    eid="102",
            //    time= "2015-05-26 01:40:38",
            //    begin="0",
            //    count="1000"
            //};
            //byte[] bytes = YUNAPI.FileReader("D:/working/102.key");

            //string key = YUNAPI.EncryptToRSA(bytes.ToString());
            //string dataJSON = JsonConvert.SerializeObject(data);
            //KeyValuePair<string, string> kvp_data = new KeyValuePair<string, string>("data",dataJSON);

            //msg.Add(kvp_nonce);
            //msg.Add(kvp_eid);
            //msg.Add(kvp_data);

            //message = JsonConvert.SerializeObject(msg);

            var result = new PerOutputDTO();
            
            var resultTmp = await PostDataAsync(url, message);
            JObject obj = (JObject)JsonConvert.DeserializeObject(resultTmp);

            JObject obj_data= (JObject)obj.GetValue("data");

            //Console.WriteLine(obj.ToString());
            //var members = obj["data"];
            //result.name = (string)members["name"];
            //result.openId = (string)members["openId"];
            //result.department = (string)members["department"];

            //result.email = (string)members["email"];
            //result.gender = (int)members["gender"];
            //result.isHidePhone = (string)members["isHidePhone"];
            //result.jobTitle = (string)members["jobTitle"];
            //result.orgUserType = (int)members["orgUserType"];
            //result.status = (int)members["status"];
            //result.weight = (int)members["weight"];
            //result.phone = (string)members["phone"];
            //result.photoUrl = (string)members["photoUrl"];

            return result;
        }
        #endregion


        #region RSA加密
        /// <summary>
        /// RSA加密
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string EncryptToRSA(string str)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            
            
            byte[] str1 = Encoding.UTF8.GetBytes(str);
            
            byte[] str2 = rsa.Encrypt(str1,true);
       
            rsa.Clear();
            (rsa as IDisposable).Dispose();
            string tmp = BitConverter.ToString(str2).ToLower().Replace("-", ":");
            Console.WriteLine(tmp);
            return BitConverter.ToString(str2).ToLower().Replace("-", "");
            
        }




        public static byte[] restorePrivateKey(string str)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();


            byte[] str1 = Encoding.UTF8.GetBytes(str);

            byte[] str2 = rsa.Encrypt(str1, true);

            rsa.Clear();
            (rsa as IDisposable).Dispose();
            //string tmp = BitConverter.ToString(str2).ToLower().Replace("-", "");
            //Console.WriteLine(tmp);
            //byte[] result = Convert.FromBase64String(tmp);
            return str2;


        }


        /// <summary>
        /// 文件读取
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static byte[] fileReader(string path)
        {
            FileStream fs;
            StreamReader sr;
           
            
            byte[] bytes ;
            try
            {
                fs = new FileStream(path, FileMode.Open);
                sr = new StreamReader(fs, Encoding.UTF8);
                bytes = new byte[fs.Length];
                fs.Read(bytes, 0, bytes.Length);
                
                sr.Close();
                fs.Close();

                return bytes;

            }
            catch (Exception e)
            {

            }
            
            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static byte[] encryptLarger(string data,byte[] key) {


            RNGCryptoServiceProvider rngcrypt = new RNGCryptoServiceProvider();
            byte[] secretKey = new byte[16];
            rngcrypt.GetBytes(secretKey);

            byte[] exponent = { 1, 0, 1 };
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();

            RSAParameters keyinfo = new RSAParameters();
            keyinfo.Modulus = key;
            keyinfo.Exponent = exponent;
            rsa.ImportParameters(keyinfo);
            byte[] ciphedKey = rsa.Encrypt(secretKey, true);

          
            Console.WriteLine("key:"+Convert.ToBase64String(ciphedKey));
            

            AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
            aes.Padding = PaddingMode.PKCS7;
            aes.Mode = CipherMode.ECB;
            
            //aes.Key = GetAesKey(Encoding.UTF8.GetString(secretKey));
            aes.Key = secretKey;

            byte[] ciphedData;
            using (ICryptoTransform cryptoTransform = aes.CreateEncryptor())
            {
                byte[] inputBuffers = Encoding.UTF8.GetBytes(data);
                byte[] results = cryptoTransform.TransformFinalBlock(inputBuffers, 0, inputBuffers.Length);
                aes.Clear();
                aes.Dispose();
                //ciphedData = Encoding.UTF8.GetBytes(Convert.ToBase64String(results, 0, results.Length));
                ciphedData = results;
            }
            Console.WriteLine("data:"+Convert.ToBase64String(ciphedData));

            byte[] result = new byte[ciphedKey.Length + ciphedData.Length];
            Array.Copy(ciphedKey,0,result,0, ciphedKey.Length);
            Array.Copy(ciphedData,0,result, ciphedKey.Length,ciphedData.Length);
            
            Console.WriteLine("result:"+Convert.ToBase64String(result));

            return result;

        }


        public static String encrypt(String data) {
            String path = "D:/working/102.key";
            byte[] b = fileReader(path);
            byte[] key=restorePrivateKey(Convert.ToBase64String(b));
            byte[] bytes = Convert.FromBase64String(Encoding.UTF8.GetString( encryptLarger(data, key)));
            return Encoding.UTF8.GetString(bytes);
        }



       /// <summary>
       /// 补全字节到32位
       /// </summary>
       /// <param name="key"></param>
       /// <returns></returns>
       public static byte[] GetAesKey(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                throw new ArgumentNullException("key", "Aes密钥不能为空");
            }
            if (key.Length < 32)
            {
                // 不足32补全
                key = key.PadRight(32, '0');
            }
            if (key.Length > 32)
            {
                key = key.Substring(0, 32);
            }
            return Encoding.UTF8.GetBytes(key);
        }

      
       
        #endregion
    }
    public class ASCIIStringCompare :System.Collections.IComparer
    {
       
        public int Compare(object xo, object yo)
        {
            String x = xo.ToString();
            String y = yo.ToString();
            if (x.CompareTo(y) == 0)
            {
                return 0;
            }
            if (x.Length == 0)
            {
                return -1;
            }
            if (y.Length == 0)
            {
                return 1;
            }
            if ((int)x.First() == (int)y.First())
            {
                return Compare(x.Substring(1), y.Substring(1));
            }

            return ((int)x.First()).CompareTo((int)y.First());
        }
    }

    
}
