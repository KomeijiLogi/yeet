﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YUN
{
    public class DeptOutputDTO
    {
        public string id;         //组织ID

        public string parentId;   //组织父ID

        public string name;       //组织名称

        public string department; //组织长名称 
    }
}
